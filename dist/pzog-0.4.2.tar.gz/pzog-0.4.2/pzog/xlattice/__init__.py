# ~/dev/py/pzog/pzog/xlattice/__init__.py
import re
NODEID_RE = re.compile('^[0-9A-Fa-f]{40}$')
