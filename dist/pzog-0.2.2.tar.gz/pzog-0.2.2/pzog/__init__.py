# ~/dev/py/pzog/pzog/__init__.py

__version__      = '0.2.2'
__version_date__ = '2012-09-25'

__all__ = [ '__version__', '__version_date__',
            'PZOG_MAX_MSG', 'PZOG_PORT', 'RING_MACHINES',

            # methods
            'ringSize', 
          ]

# the maximum number of bytes in a message
PZOG_MAX_MSG = 512

PZOG_PORT    = 55552        # for this version, v0.2.x

RING_MACHINES = ['losaltos.dixons.org', 'test.dixons.org', 
                 'losgatos.dixons.org', 'supermicro.dixons.org',
                 'guadalupe.dixons.org',
                ]

@property 
def ringSize():
    return len(RING_MACHINES)

