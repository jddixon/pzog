# ~/dev/py/pzog/pzog/xlattice/node.py

import os
from Crypto.Hash            import SHA          as sha
from Crypto.PublicKey       import RSA          as rsa
#from Crypto.Signature       import PKCS1_PSS    as pkcs1
from Crypto.Signature       import PKCS1_v1_5   as pkcs1

import u                    # NULL_SHA1 is a 40-character hex string, all zeros
#from pzog.xlattice.crypto import getIDAndPubKeyForNode, createPrivateKey

class AbstractNode(object):
    def __init__(self, pubKey=None, nodeID=None):
        if not nodeID:
            if pubKey:
                # pycrypto's pubkey is a tuple.  str(pubkey) returns pubkey[1]
                h       = sha.new()
                h.update(pubKey[1])
                nodeID  = h.hexdigest()
            else:
                raise ValueError('cannot calculate nodeID without pubKey')

        self._nodeID = nodeID
        self._pubKey = pubKey

    @property
    def nodeID(self): return self._nodeID
    
    """ 
    Returns a 2-tuple, the second element of which is the key 
    in what might be called 'export' format.
    """
    @property
    def pubKey(self): return self._pubKey

class Node(AbstractNode):
    """
    """
    def __init__(self, privateKey=rsa.generate(2048, os.urandom)):
        AbstractNode.__init__(self,  
                              Node.getIDAndPubKeyForNode(self, privateKey ))

        if not privateKey:
            raise ValueError('INTERNAL ERROR: undefined private key')
        self._privateKey = privateKey

        # each of these some sort of map or maps, or we will need to do
        # a linear search
        self._peers         = []
        self._overlays      = []    #
        self._connections   = []    # with peers? with clients?

    def createFromKey(self, s):
        # XXX STUB: given the serialization of a node, create one
        # despite the name, this should also handle peer lists, etc
        # XXX WE ALSO NEED a serialization function
        pass

    @staticmethod
    def getIDAndPubKeyForNode(node, rsaPrivateKey):
        
        (nodeID, pubKey) = (None, None)
        # generate the public key from the private key; will be in PEM format
        pubKey = rsaPrivateKey.publickey().exportKey()
    
        # DEBUG
        # print "public key is %s" % str(pubKey)
        # END
    
        # generate the nodeID from the public key
        h       = sha.new()
        h.update(pubKey)
        nodeID  = h.hexdigest()
        return (nodeID,                 # nodeID = 160 bit value
                pubKey)                 # from private key          # GEEP

    def key(self):
        return self._privateKey

    # these work with 
    def sign(self, msg):
        signer  = pkcs1.new(self._privateKey)
        h       = sha.new()
        h.update(msg)
        #hash    = h.digest()
        return signer.sign(h)           # h was hash

    # THIS IS WRONG: we verify using the PUBLIC key
    def verify(self, msg, signature):
        verifier= pkcs1.new(self._privateKey)
        h       = sha.new()
        h.update(msg)
        #hash    = h.digest()    
        return verifier.verify(h, signature)    # h was hash

class Peer(AbstractNode):
    """ a Peer is a Node seen from the outside """
    def __init__(self, nodeID, pubKey):
        AbstractNode.__init__(self, (nodeID, pubKey))
