# pzog

Initial commit.

## Implementation Nodes

* [crypto](https://jddixon.github.io/pzog/crypto.html)

## Project Status

Alpha.  Partical (well, skeletal) implementation exists but is untested.

## On-line Documentation

More information on the **pzog** project can be found
[here](https://jddixon.github.io/pzog)
